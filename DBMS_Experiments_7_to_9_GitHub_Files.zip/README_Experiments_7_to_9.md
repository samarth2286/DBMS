# DBMS Lab Experiments 7–9

These source files are GitHub-friendly plain-text code files.

- Experiments 7A–9B: MongoDB Shell (`.js`) files. Run with `mongosh <filename.js>` or paste the contents into MongoDB Compass Playground.
- Experiment 9C: Python (`.py`) file for MySQL connectivity.

For Experiment 9C, install dependencies:
```bash
pip install mysql-connector-python tabulate
```
Update `YOUR_PASSWORD` in the Python file with your local MySQL password before running it.
